package io.storecamera.storecamera_photo.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
