package io.storecamera.storecamera_photo.storecamera_plugin_camera.data

interface PluginToMap {
    fun pluginToMap(): Map<String, *>
}

