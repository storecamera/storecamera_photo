package io.storecamera.storecamera_photo.storecamera_plugin_media.data

interface PluginToMap {
    fun pluginToMap(): Map<String, *>
}

